window.__AUCTION_CONFIG__ = {
  region: "ap-southeast-2",
  userPoolId: "ap-southeast-2_Y4dEG8QGD",
  clientId: "2edue0clehhu521c8pce5ji9jo",
  websocketUrl: "wss://8mzec14na1.execute-api.ap-southeast-2.amazonaws.com/prod"
};
