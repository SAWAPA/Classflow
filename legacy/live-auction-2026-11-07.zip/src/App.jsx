import { useEffect, useMemo, useRef, useState } from "react";

const config = window.__AUCTION_CONFIG__ || {};
const savedSession = JSON.parse(localStorage.getItem("auction-session") || "null");

function formatMoney(value) {
  return new Intl.NumberFormat("th-TH", {
    style: "currency",
    currency: "THB",
    maximumFractionDigits: 2
  }).format(Number(value || 0));
}

function formatTime(value) {
  if (!value) return "-";
  return new Date(value).toLocaleString("th-TH", {
    dateStyle: "medium",
    timeStyle: "short"
  });
}

function decodeJwt(token) {
  try {
    const payload = token.split(".")[1];
    return JSON.parse(atob(payload.replace(/-/g, "+").replace(/_/g, "/")));
  } catch {
    return {};
  }
}

async function cognitoRequest(target, body) {
  const response = await fetch(`https://cognito-idp.${config.region}.amazonaws.com/`, {
    method: "POST",
    headers: {
      "Content-Type": "application/x-amz-json-1.1",
      "X-Amz-Target": `AWSCognitoIdentityProviderService.${target}`
    },
    body: JSON.stringify(body)
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.message || "Cognito request failed");
  return data;
}

function AuthPanel({ onLogin }) {
  const [mode, setMode] = useState("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [code, setCode] = useState("");
  const [notice, setNotice] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(event) {
    event.preventDefault();
    setNotice("");
    setBusy(true);
    try {
      if (mode === "signup") {
        await cognitoRequest("SignUp", {
          ClientId: config.clientId,
          Username: email,
          Password: password,
          UserAttributes: [{ Name: "email", Value: email }]
        });
        setMode("confirm");
        setNotice("สมัครสมาชิกแล้ว กรุณาตรวจสอบรหัสยืนยันในอีเมล");
      } else if (mode === "confirm") {
        await cognitoRequest("ConfirmSignUp", {
          ClientId: config.clientId,
          Username: email,
          ConfirmationCode: code
        });
        setMode("signin");
        setNotice("ยืนยันบัญชีสำเร็จ กรุณาเข้าสู่ระบบ");
      } else {
        const result = await cognitoRequest("InitiateAuth", {
          ClientId: config.clientId,
          AuthFlow: "USER_PASSWORD_AUTH",
          AuthParameters: { USERNAME: email, PASSWORD: password }
        });
        const token = result.AuthenticationResult.IdToken;
        const claims = decodeJwt(token);
        onLogin({
          token,
          email,
          username: claims["cognito:username"] || email,
          sub: claims.sub
        });
      }
    } catch (error) {
      setNotice(error.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="auth-shell">
      <section className="hero-card">
        <div className="eyebrow">SERVERLESS • REAL-TIME • FAIR BIDDING</div>
        <h1>Live Auction</h1>
        <p>ประมูลแบบเรียลไทม์ เห็นราคาล่าสุดพร้อมกันทุกคน และป้องกันการบิดชนกันด้วย atomic write</p>
        <div className="hero-points">
          <span>⚡ WebSocket</span><span>🔒 Cognito</span><span>◈ DynamoDB</span>
        </div>
      </section>
      <section className="panel auth-card">
        <div className="tabs">
          <button className={mode === "signin" ? "active" : ""} onClick={() => setMode("signin")}>เข้าสู่ระบบ</button>
          <button className={mode === "signup" ? "active" : ""} onClick={() => setMode("signup")}>สมัครสมาชิก</button>
          {mode === "confirm" && <button className="active">ยืนยันอีเมล</button>}
        </div>
        <form onSubmit={submit}>
          <label>อีเมล<input type="email" value={email} onChange={(e) => setEmail(e.target.value)} required /></label>
          {mode !== "confirm" && <label>รหัสผ่าน<input type="password" minLength="8" value={password} onChange={(e) => setPassword(e.target.value)} required /></label>}
          {mode === "confirm" && <label>รหัสยืนยัน<input inputMode="numeric" value={code} onChange={(e) => setCode(e.target.value)} required /></label>}
          <button className="primary full" disabled={busy} type="submit">{busy ? "กำลังดำเนินการ..." : mode === "signin" ? "เข้าสู่ระบบ" : mode === "signup" ? "สร้างบัญชี" : "ยืนยันบัญชี"}</button>
        </form>
        {notice && <div className="notice">{notice}</div>}
        <small>ข้อมูลบัญชีถูกจัดการโดย Amazon Cognito ไม่เก็บรหัสผ่านไว้ในแอป</small>
      </section>
    </main>
  );
}

function AuctionCard({ auction, selected, onSelect }) {
  return (
    <button className={`auction-card ${selected ? "selected" : ""}`} onClick={() => onSelect(auction)}>
      <div className="auction-card-top"><span className={`status ${auction.status === "OPEN" ? "open" : "closed"}`}>{auction.status === "OPEN" ? "กำลังประมูล" : "ปิดแล้ว"}</span><span>{formatTime(auction.endsAt)}</span></div>
      <h3>{auction.title}</h3>
      <p>{auction.description || "ไม่มีรายละเอียด"}</p>
      <div className="price-row"><span>ราคาปัจจุบัน</span><strong>{formatMoney(auction.currentPrice)}</strong></div>
      <div className="muted">เพิ่มขั้นต่ำ {formatMoney(auction.minIncrement)}</div>
    </button>
  );
}

function App() {
  const [session, setSession] = useState(savedSession);
  const [auctions, setAuctions] = useState([]);
  const [selected, setSelected] = useState(null);
  const [history, setHistory] = useState([]);
  const [bidAmount, setBidAmount] = useState("");
  const [newAuction, setNewAuction] = useState({ title: "", description: "", startingPrice: "", minIncrement: "", duration: "10" });
  const [notice, setNotice] = useState("");
  const [socketState, setSocketState] = useState("กำลังเชื่อมต่อ...");
  const socketRef = useRef(null);

  const activeAuction = useMemo(() => auctions.find((item) => item.auctionId === selected?.auctionId) || selected, [auctions, selected]);

  function saveSession(next) {
    localStorage.setItem("auction-session", JSON.stringify(next));
    setSession(next);
  }

  function send(payload) {
    if (!socketRef.current || socketRef.current.readyState !== WebSocket.OPEN) {
      setNotice("ยังไม่ได้เชื่อมต่อกับระบบประมูล");
      return;
    }
    socketRef.current.send(JSON.stringify(payload));
  }

  function connect(auctionId = "") {
    if (!session?.token || !config.websocketUrl || config.websocketUrl === "REPLACE_ME") return;
    socketRef.current?.close();
    const suffix = auctionId ? `&auctionId=${encodeURIComponent(auctionId)}` : "";
    const socket = new WebSocket(`${config.websocketUrl}?Authorization=${encodeURIComponent(session.token)}${suffix}`);
    socketRef.current = socket;
    setSocketState("กำลังเชื่อมต่อ...");
    socket.onopen = () => {
      setSocketState("เชื่อมต่อแล้ว");
      send({ action: "listAuctions" });
      if (auctionId) {
        send({ action: "getAuction", auctionId });
        send({ action: "getHistory", auctionId });
      }
    };
    socket.onclose = () => setSocketState("ตัดการเชื่อมต่อ");
    socket.onerror = () => setSocketState("เชื่อมต่อผิดพลาด");
    socket.onmessage = (event) => {
      const message = JSON.parse(event.data);
      if (message.type === "error") setNotice(message.message);
      if (message.type === "auctions") setAuctions(message.items || []);
      if (message.type === "auction") {
        setSelected(message.item);
        setAuctions((items) => items.map((item) => item.auctionId === message.item.auctionId ? message.item : item));
      }
      if (message.type === "history") setHistory(message.items || []);
      if (message.type === "bidUpdate") {
        setAuctions((items) => items.map((item) => item.auctionId === message.item.auctionId ? { ...item, ...message.item } : item));
        setSelected((item) => item?.auctionId === message.item.auctionId ? { ...item, ...message.item } : item);
        setHistory((items) => [message.bid, ...items].slice(0, 20));
        setNotice(`มีการบิดใหม่ที่ ${formatMoney(message.bid.amount)}`);
      }
      if (message.type === "created") {
        setAuctions((items) => [message.item, ...items]);
        setNotice("สร้างรายการประมูลแล้ว");
      }
      if (message.type === "closed") {
        setAuctions((items) => items.map((item) => item.auctionId === message.item.auctionId ? message.item : item));
        setSelected((item) => item?.auctionId === message.item.auctionId ? message.item : item);
      }
    };
  }

  useEffect(() => {
    if (session) connect();
    return () => socketRef.current?.close();
  }, [session]);

  function logout() {
    socketRef.current?.close();
    localStorage.removeItem("auction-session");
    setSession(null);
    setSelected(null);
  }

  function selectAuction(auction) {
    setSelected(auction);
    setHistory([]);
    connect(auction.auctionId);
  }

  function placeBid(event) {
    event.preventDefault();
    if (!activeAuction) return;
    send({ action: "placeBid", auctionId: activeAuction.auctionId, amount: Number(bidAmount) });
    setBidAmount("");
  }

  function createAuction(event) {
    event.preventDefault();
    const endsAt = new Date(Date.now() + Number(newAuction.duration) * 60 * 1000).toISOString();
    send({
      action: "createAuction",
      title: newAuction.title,
      description: newAuction.description,
      startingPrice: Number(newAuction.startingPrice),
      minIncrement: Number(newAuction.minIncrement),
      endsAt
    });
    setNewAuction({ title: "", description: "", startingPrice: "", minIncrement: "", duration: "10" });
  }

  if (!session) return <AuthPanel onLogin={saveSession} />;

  return (
    <div className="app-shell">
      <header className="topbar"><div><div className="eyebrow">LIVE AUCTION PLATFORM</div><h1>ห้องประมูลของชุมชน</h1></div><div className="topbar-actions"><span className="connection"><i className={socketState === "เชื่อมต่อแล้ว" ? "online" : ""}></i>{socketState}</span><span className="user-pill">{session.email}</span><button className="ghost" onClick={logout}>ออกจากระบบ</button></div></header>
      {notice && <div className="toast" onClick={() => setNotice("")}>{notice}</div>}
      <main className="dashboard">
        <section className="panel create-panel"><div className="section-heading"><div><span className="eyebrow">CREATE</span><h2>สร้างรายการประมูล</h2></div><span className="service-chip">DynamoDB conditional write</span></div>
          <form className="create-form" onSubmit={createAuction}><label>ชื่อสินค้า<input value={newAuction.title} onChange={(e) => setNewAuction({ ...newAuction, title: e.target.value })} required /></label><label>รายละเอียด<input value={newAuction.description} onChange={(e) => setNewAuction({ ...newAuction, description: e.target.value })} /></label><div className="form-grid"><label>ราคาเริ่มต้น<input type="number" min="1" value={newAuction.startingPrice} onChange={(e) => setNewAuction({ ...newAuction, startingPrice: e.target.value })} required /></label><label>เพิ่มขั้นต่ำ<input type="number" min="1" value={newAuction.minIncrement} onChange={(e) => setNewAuction({ ...newAuction, minIncrement: e.target.value })} required /></label><label>เวลา (นาที)<input type="number" min="1" max="60" value={newAuction.duration} onChange={(e) => setNewAuction({ ...newAuction, duration: e.target.value })} required /></label></div><button className="primary" type="submit">+ เปิดประมูล</button></form>
        </section>
        <div className="content-grid"><section><div className="section-heading"><div><span className="eyebrow">MARKETPLACE</span><h2>รายการประมูล</h2></div><span className="muted">{auctions.length} รายการ</span></div><div className="auction-list">{auctions.length ? auctions.map((auction) => <AuctionCard key={auction.auctionId} auction={auction} selected={activeAuction?.auctionId === auction.auctionId} onSelect={selectAuction} />) : <div className="empty">ยังไม่มีรายการประมูล ลองสร้างรายการแรก</div>}</div></section>
          <section className="panel detail-panel">{activeAuction ? <><div className="detail-header"><div><span className={`status ${activeAuction.status === "OPEN" ? "open" : "closed"}`}>{activeAuction.status === "OPEN" ? "กำลังประมูล" : "ปิดแล้ว"}</span><h2>{activeAuction.title}</h2><p>{activeAuction.description}</p></div><div className="countdown">สิ้นสุด<br /><strong>{formatTime(activeAuction.endsAt)}</strong></div></div><div className="big-price"><span>ราคาปัจจุบัน</span><strong>{formatMoney(activeAuction.currentPrice)}</strong><small>ผู้ชนะล่าสุด: {activeAuction.highestBidderName || "ยังไม่มี"}</small></div>{activeAuction.status === "OPEN" && <form className="bid-form" onSubmit={placeBid}><input type="number" min={Number(activeAuction.currentPrice) + Number(activeAuction.minIncrement)} placeholder={`อย่างน้อย ${formatMoney(Number(activeAuction.currentPrice) + Number(activeAuction.minIncrement))}`} value={bidAmount} onChange={(e) => setBidAmount(e.target.value)} required /><button className="primary" type="submit">เสนอราคา</button></form>}<div className="history"><div className="section-heading"><h3>ประวัติการบิด</h3><span className="muted">เรียลไทม์</span></div>{history.length ? history.map((bid) => <div className="history-row" key={bid.bidId}><span>{bid.bidderName || "ผู้เข้าร่วม"}</span><strong>{formatMoney(bid.amount)}</strong><time>{formatTime(bid.createdAt)}</time></div>) : <div className="empty small">ยังไม่มีการบิดในรายการนี้</div>}</div></> : <div className="empty detail-empty">เลือกรายการประมูลเพื่อดูรายละเอียดและเสนอราคา</div>}</section></div>
      </main>
      <footer>Compute: AWS Lambda · Realtime: API Gateway WebSocket · Storage: Amazon S3 · Database: DynamoDB · Auth: Cognito</footer>
    </div>
  );
}

export default App;
