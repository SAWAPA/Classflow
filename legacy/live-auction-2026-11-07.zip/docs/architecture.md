# Live Auction Platform - Cloud Architecture

## Architecture and data flow

```mermaid
flowchart LR
  U[Browser / React SPA] -->|HTTPS static assets| S3[(Amazon S3<br/>Static website)]
  U -->|Sign up / sign in| C[Cognito User Pool]
  U -->|WSS action messages| WS[API Gateway<br/>WebSocket API]
  WS -->|$connect + JWT query token| AUTH[Lambda Authorizer]
  WS -->|$connect| CON[Lambda Connect]
  WS -->|$disconnect| DISC[Lambda Disconnect]
  WS -->|create/list/get/bid| MSG[Lambda Message Handler]
  MSG --> A[(DynamoDB Auctions)]
  MSG --> B[(DynamoDB Bids)]
  MSG --> X[(DynamoDB Connections)]
  MSG -->|PostToConnection broadcast| WS
  EB[EventBridge rate(1 minute)] --> CLOSE[Lambda Auto-close]
  CLOSE --> A
  CLOSE --> X
  CLOSE -->|closed event| WS
```

## Why this is cost-conscious

- There are no always-on virtual machines, NAT gateways, load balancers, or VPC resources.
- DynamoDB uses on-demand billing, so an idle demo does not pay for provisioned capacity.
- Lambda is kept at 128 MB for lightweight handlers; the message handler is 256 MB for the WebSocket SDK and concurrency path.
- EventBridge runs once per minute because auction closing does not need second-level polling.
- S3 hosts both the frontend and its static assets. CloudFront is intentionally omitted for this classroom-scale demo to avoid another managed service and distribution setup.
- All demo test data is small. The intended safety envelope is a limited classroom demo, not a production marketplace.

## Security choices

- Cognito issues the ID token used during the WebSocket `$connect` handshake.
- A Lambda authorizer verifies the Cognito JWT signature, issuer, expiry, and audience before allowing the connection.
- All data access happens through one least-scope IAM role with table-specific DynamoDB permissions.
- Secrets are not stored in source code. The browser receives only the public Cognito client id and WebSocket endpoint.
- The S3 bucket is public only for static website reads. No write permission is public.

## Concurrency guarantee

`placeBid` reads the current price for user feedback, then performs a DynamoDB `TransactWriteItems` operation. The auction update includes a condition that the stored price still equals the price that was read. If two users bid at the same time, only one transaction can update that exact price; the other receives a conflict and must retry.
