# Live Auction Platform

Serverless real-time auction platform for the Cloud Computing and Virtualization Technology project.

The implementation follows the proposal and the marking rubric: React frontend, S3 static hosting, Cognito authentication, API Gateway WebSocket, Lambda compute, DynamoDB transactional/conditional bidding, and EventBridge scheduled auto-close.

## Local setup

```powershell
cd frontend
npm install
npm run dev
```

The deployed values are written to `frontend/public/config.js` and bundled into `frontend/dist/config.js`.

## Current AWS demo

- Website: http://live-auction-platform-frontendbucket-ujdquypvxfmq.s3-website-ap-southeast-2.amazonaws.com/
- Region: `ap-southeast-2`
- CloudFormation stack: `live-auction-platform`
- Stack status: `CREATE_COMPLETE`

## Cloud deployment

1. Create a CloudFormation stack from `infra/template.yaml` in the project AWS account.
2. Enable IAM capabilities when the console asks for them.
3. Wait until the stack reaches `CREATE_COMPLETE`.
4. Copy the stack outputs into `frontend/public/config.js` (`region`, `userPoolId`, `clientId`, and `websocketUrl`).
5. Build the frontend with `npm run build`.
6. Upload the contents of `frontend/dist` to the output `FrontendBucketName` and open `FrontendWebsiteUrl`.

For the current deployment, the frontend was uploaded as four objects: `index.html`, `config.js`, and the two files under `assets/`.

## Cost guardrails

This stack intentionally avoids EC2, RDS, NAT Gateway, load balancers, CloudFront, and provisioned DynamoDB capacity. During development, use small test windows and disconnect idle WebSocket tabs. After the demo, delete the CloudFormation stack and verify the S3 bucket is empty if the bucket cannot be deleted automatically.

## Rubric mapping

- Architecture: `docs/architecture.md` contains the component and data-flow diagram.
- Compute: Lambda functions for authorization, connection lifecycle, message handling, and scheduled close.
- Storage: S3 static website hosting.
- Database: DynamoDB tables for auctions, bids, and active WebSocket connections.
- Reliability/security: stateless handlers, JWT verification, DynamoDB transaction condition, TTL cleanup, and scheduled close.
- Bonus-ready: the repository is structured for GitHub Actions/SAM deployment, while the first deployment is intentionally kept manual to avoid introducing extra paid services.
